module.exports = function (context, req) {  
  context.res = {
    body: req.body + " It's nice to see you!"
  };
  context.done();
};