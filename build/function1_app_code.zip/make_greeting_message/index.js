module.exports = function (context, data) {  
  context.res = {
    body: "Hello " + context.req.body.name + " " + context.req.body.lastname + "."
  };
  context.done();
};